<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
try {
    if(isset($_POST['categoryName'])) {
        updateC($pdo, $_POST['categoryid'], $_POST['categoryName']);
        header('location: adminDisplay.php');
    }else{
        $categories = allCategories($pdo);
        $title = 'Edit module name';

        ob_start();
        include '../templates/catTable.html.php';
        $output = ob_get_clean();
    }
}catch (PDOException $e) {
    $title = 'An error has occured';
    $output = 'Error editing category: ' . $e->getMessage();
}
include '../templates/admin_layout.html.php';