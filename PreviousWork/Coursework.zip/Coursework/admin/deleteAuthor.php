<?php
try{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';
    deleteA($pdo, $_POST['id']);
    header('location: author.php');

}catch (PDOException $e) {
    $title = 'An error has occured';
    $output = 'Unable to connect to delete question: ' . $e->getMessage();
}
include '../templates/admin_layout.html.php';