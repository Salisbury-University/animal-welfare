<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
try {
    if(isset($_POST['name'])) {
        updateA($pdo, $_POST['authorid'], $_POST['name']);
        header('location: adminDisplay.php');
    }else{
        $authors = allAuthors($pdo);
        $title = 'Edit author name';

        ob_start();
        include '../templates/authorTable.html.php';
        $output = ob_get_clean();
    }
}catch (PDOException $e) {
    $title = 'An error has occured';
    $output = 'Error editing author: ' . $e->getMessage();
}
include '../templates/admin_layout.html.php';