<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
try {
    if(isset($_POST['text'])) {
        updateAdmin($pdo, $_POST['id'], $_POST['text'], $_POST['categories']);
        header('location: adminDisplay.php');
    }else{
        $title = 'Edit question';
        $question = getQ($pdo, $_GET['id']);
        $authors = allAuthors($pdo);
        $categories = allCategories($pdo);

        ob_start();
        include '../templates/editAdmin.html.php';
        $output = ob_get_clean();
    }
}catch (PDOException $e) {
    $title = 'An error has occured';
    $output = 'Error editing question: ' . $e->getMessage();
}
include '../templates/admin_layout.html.php';