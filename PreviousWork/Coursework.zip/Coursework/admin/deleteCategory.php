<?php
try{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';
    deleteC($pdo, $_POST['id']);
    header('location: category.php');

}catch (PDOException $e) {
    $title = 'An error has occured';
    $output = 'Unable to connect to delete category: ' . $e->getMessage();
}
include '../templates/admin_layout.html.php';