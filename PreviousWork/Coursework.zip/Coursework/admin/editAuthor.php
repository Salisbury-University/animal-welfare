<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
try {
    if(isset($_POST['name'])) {
        updateA($pdo, $_POST['id'], $_POST['name'], $_POST['email']);
        header('location: author.php');
    }else{
        $author = getA($pdo, $_GET['id']);
        $title = 'Edit author';

        ob_start();
        include '../templates/editAuthor.html.php';
        $output = ob_get_clean();
    }
}catch (PDOException $e) {
    $title = 'An error has occured';
    $output = 'Error editing author: ' . $e->getMessage();
}
include '../templates/admin_layout.html.php';