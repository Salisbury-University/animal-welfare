<?php
if(isset($_POST['categoryName'])) {
    try{
        include '../includes/DatabaseConnection.php';
        include '../includes/DatabaseFunctions.php';
        insertCat($pdo, $_POST['categoryName']);
        header('location: category.php');
    }catch (PDOException $e) {
        $title = 'An error has occured';
        $output = 'Unable to connect to add question: ' . $e->getMessage();
    }
}else {
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';
    $title = 'Add Module';
    $authors = allAuthors($pdo);
    $categories = allCategories($pdo);
    ob_start();
    include '../templates/addModule.html.php';
    $output = ob_get_clean();
}

include '../templates/admin_layout.html.php';