<table border = '1px'>
<?php foreach ($categories as $category): ?>
    <tr>
        <td width="350px"> <?=htmlspecialchars($category['categoryName'],ENT_QUOTES,'UTF-8')?></td>
        
        <td width="100px" > <a href="editCat.php?id=<?=$category['id']?>">Edit</a></td>
        <td width="350px">
            <form action = "deleteCategory.php" method = "post">
                <input type = "hidden" name = "id" value = "<?=$category['id']?>">
                <input type = "submit" value = "Delete">
            </form>
        </td>
    </tr>
<?php endforeach;?>
</table>
<br>
Add New Module:
<a href="addCat.php?id=<?=$category['id']?>">Add</a>
