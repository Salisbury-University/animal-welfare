<p><?=$totalQuestions?> questions have been submitted to the Forum.</p>

<table border = '1px'>
<?php foreach ($questions as $question): ?>
    <tr>
        <td width="150px">
        <img height="100px" src="images/<?=htmlspecialchars($question['image'], ENT_QUOTES, 'UTF-8'); ?>" /></td>    
        <td width="350px"> <?=htmlspecialchars($question['text'],ENT_QUOTES,'UTF-8')?></td>
        <td width="400px"> <?=htmlspecialchars($question['categoryName'], ENT_QUOTES, 'UTF-8')?>
        <td width="450px"> (by <a href="mailto:<?=htmlspecialchars($question['email'], ENT_QUOTES, 'UTF-8'); ?>">
        <?=htmlspecialchars($question['name'], ENT_QUOTES, 'UTF-8'); ?></a>)
        <a href="edit.php?id=<?=$question['id']?>">Edit</a></td>
        <td width="10">
            <form action = "delete.php" method = "post">
                <input type = "hidden" name = "id" value = "<?=$question['id']?>">
                <input type = "submit" value = "Delete">
            </form>
        </td>
    </tr>
<?php endforeach;?>
</table>