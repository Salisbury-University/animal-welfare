<form action ="" method = "post">
    <input type="hidden" name="id" value="<?=$question['id'];?>">

    <label for='text'>Make edits to your question here:</label>
    <textarea name="text" rows = "3" cols="40"><?=htmlspecialchars($question['text'],ENT_QUOTES,'UTF-8')?></textarea>

    <label for='text'>Reassign Question Module:</label>
    <select name="categories">
        <option value="">select correct module</option>
        <?php foreach ($categories as $category):?>
            <option value="<?=htmlspecialchars($category['id'], ENT_QUOTES, 'UTF-8'); ?>">
            <?=htmlspecialchars($category['categoryName'], ENT_QUOTES, 'UTF-8');?>
            </option>
            <?php endforeach;?>
    </select>

    <input type = "submit" name = "submit" value = "Save">
</form>