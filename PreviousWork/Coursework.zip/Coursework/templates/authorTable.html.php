<table border = '1px'>
<?php foreach ($authors as $author): ?>
    <tr>
        <td width="350px"> <?=htmlspecialchars($author['name'],ENT_QUOTES,'UTF-8')?></td>
        <td width="400px"> <?=htmlspecialchars($author['email'], ENT_QUOTES, 'UTF-8')?>
        
        <td width="100px" > <a href="editAuthor.php?id=<?=$author['id']?>">Edit</a></td>
        
        <td width="350px">
            <form action = "deleteAuthor.php" method = "post">
                <input type = "hidden" name = "id" value = "<?=$author['id']?>">
                <input type = "submit" value = "Delete">
            </form>
        </td>
    </tr>
<?php endforeach;?>
</table>
<br>
Add New Student:
<a href="addAuthor.php?id=<?=$author['id']?>">Add</a>