<form action = "" method = "post">
    <input type="hidden" name="id" value="<?=$category['id'];?>">
    <label for='categoryName'>Enter module name:</label>
    <textarea name="categoryName" rows = "3" cols="40"><?=htmlspecialchars($category['categoryName'],ENT_QUOTES,'UTF-8')?></textarea>
    <input type = "submit" name = "submit" value = "Save">
</form>