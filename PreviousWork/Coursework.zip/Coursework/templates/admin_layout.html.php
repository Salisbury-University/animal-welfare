<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../admin.css">
        <title><?=$title?></title>
    </head>
    <body>
        <header><h1>Student Forum Admin Area<br />
        Manage questions, categories, and authors</h1></header>
        <nav>
            <ul>
                <li><a href="adminDisplay.php">Question List</a></li>
                <li><a href="add.php">Add New Question</a></li>
                <li><a href="author.php">Edit Authors</a></li>
                <li><a href="category.php">Edit Modules</a></li>
                <li><a href="../index.php">Public Site</a></li>
            </ul>
        </nav>
        <main>
            <?=$output?>
        </main>
        <footer>&copy; IJDB 2022</footer>
    </body>
</html>