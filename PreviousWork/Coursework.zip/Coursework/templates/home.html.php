<h2>Welcome to the Student Help Forum!</h2>
<p>Ask questions!</p>
<img src='images/think.jpg' >
