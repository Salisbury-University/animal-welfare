<form action = "" method = "post">
    <label for='name'>Enter Student Name:</label>
    <textarea name="name" rows = "3" cols="40"></textarea>

    <label for='email'>Enter Student Email:</label>
    <textarea name="email" rows = "3" cols="40"></textarea>

    <input type = "submit" name = "submit" value = "Add">
</form>