<form action = "" method = "post">
    <input type="hidden" name="id" value="<?=$author['id'];?>">
    <label for='name'>Edit correct student name:</label>
    <textarea name="name" rows = "3" cols="40"><?=htmlspecialchars($author['name'],ENT_QUOTES,'UTF-8')?></textarea>
    <label for='email'>Enter correct email:</label>
    <textarea name="email" rows = "3" cols="40"><?=htmlspecialchars($author['email'],ENT_QUOTES,'UTF-8')?></textarea>
    <input type = "submit" name = "submit" value = "Save">
</form>