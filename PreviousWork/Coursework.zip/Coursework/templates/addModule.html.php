<form action = "" method = "post">
    <label for='categoryName'>Enter Module Name:</label>
    <textarea name="categoryName" rows = "3" cols="40"></textarea>

    <input type = "submit" name = "submit" value = "Add">
</form>