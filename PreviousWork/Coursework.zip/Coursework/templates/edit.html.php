<form action = "" method = "post">
    <input type="hidden" name="questionid" value="<?=$question['id'];?>">
    <label for='text'>Edit your question here:</label>
    <textarea name="text" rows = "3" cols="40"><?=htmlspecialchars($question['text'],ENT_QUOTES,'UTF-8')?></textarea>
    <input type = "submit" name = "submit" value = "Save">
</form>