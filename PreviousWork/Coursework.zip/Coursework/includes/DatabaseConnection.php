<?php
$pdo = new PDO('mysql:host=https://lamp.salisbury.edu/phpmyadmin/; dbname=rprusacki1DB;
charset=utf8mb4', 'rprusacki1', 'rprusacki1');