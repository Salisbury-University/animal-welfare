<?php

##REUSABLE QUERY FUNCTION##

function query($pdo, $sql, $parameters = []) {
	$query = $pdo->prepare($sql);
	$query->execute($parameters);
	return $query;
}

##QUESTION FUNCTIONS##

function getQ($pdo, $id) {
	$parameters = [':id' => $id];
	$query = query($pdo, 'SELECT * FROM question WHERE id = :id', $parameters);
	return $query->fetch();
}

function totalQuestions($pdo) {
	$query = query($pdo, 'SELECT COUNT(*) FROM question');
	$row = $query->fetch();
	return $row[0];
}

function allQuestions($pdo) {
	$questions = query($pdo, 'SELECT question.id, text, name, email, categoryName, image FROM question
	INNER JOIN author ON authorid  = author.id
	INNER JOIN category ON categoryid = category.id');
	return $questions->fetchAll();
}

function insertQ($pdo, $text, $authorid, $categoryid) {
	$query = 'INSERT INTO question (text, date, authorid, categoryid)
	VALUES (:text, CURDATE(), :authorid, :categoryid)';
	$parameters = [':text' => $text, ':authorid' => $authorid, ':categoryid' => $categoryid];
	query($pdo, $query, $parameters);
}

function updateQ($pdo, $questionId, $text) {
	$query = 'UPDATE question SET text = :text WHERE id = :id';
	$parameters = [':text' => $text, ':id' => $questionId];
	query($pdo, $query, $parameters);
}

function deleteQ($pdo, $id) {
	$parameters = [':id' => $id];
	query($pdo, 'DELETE FROM question WHERE id = :id', $parameters);
}

##ADMIN##

function updateAdmin($pdo, $questionId, $text, $categoryid) {
	$query = 'UPDATE question SET text = :text, categoryid = :categoryid WHERE id = :id';
	$parameters = [':text' => $text, ':id' => $questionId, ':categoryid' => $categoryid];
	query($pdo, $query, $parameters);
}

##AUTHOR FUNCTIONS##

function allAuthors($pdo) {
	$authors = query($pdo, 'SELECT * FROM author');
	return $authors->fetchAll();
}

function updateA($pdo, $id, $name, $email) {
	$query = 'UPDATE author SET name = :name, email = :email WHERE id = :id';
	$parameters = [':name' => $name, ':id' => $id, ':email' => $email];
	query($pdo, $query, $parameters);
}

function getA($pdo, $id) {
	$parameters = [':id' => $id];
	$query = query($pdo, 'SELECT * FROM author WHERE id = :id', $parameters);
	return $query->fetch();
}

function insertA($pdo, $name, $email) {
	$query = 'INSERT INTO author (name, email) VALUES (:name, :email)';
	$parameters = [':name' => $name, ':email' => $email];
	query($pdo, $query, $parameters);
}

function deleteA($pdo, $id) {
	$parameters = [':id' => $id];
	query($pdo, 'DELETE FROM author WHERE id = :id', $parameters);
}

##CATEGORY FUNCTIONS##

function allCategories($pdo) {
	$categories = query($pdo, 'SELECT * FROM category');
	return $categories->fetchAll();
}

function updateC($pdo, $id, $categoryName) {
	$query = 'UPDATE category SET categoryName = :categoryName WHERE id = :id';
	$parameters = [':categoryName' => $categoryName, ':id' => $id];
	query($pdo, $query, $parameters);
}

function getC($pdo, $id) {
	$parameters = [':id' => $id];
	$query = query($pdo, 'SELECT * FROM category WHERE id = :id', $parameters);
	return $query->fetch();
}

function insertCat($pdo, $categoryName) {
	$query = 'INSERT INTO category (categoryName) VALUES (:categoryName)';
	$parameters = [':categoryName' => $categoryName];
	query($pdo, $query, $parameters);
}

function deleteC($pdo, $id) {
	$parameters = [':id' => $id];
	query($pdo, 'DELETE FROM category WHERE id = :id', $parameters);
}

##CONTACT FORM FUNCTIONS#

function insertC($pdo, $text, $email, $authorid, $categoryid) {
	$query = 'INSERT INTO contact (text, email, date, authorid, categoryid)
	VALUES (:text, :email, CURDATE(), :authorid, :categoryid)';
	$parameters = [':text' => $text, ':email' => $email, ':authorid' => $authorid, ':categoryid' => $categoryid];
	query($pdo, $query, $parameters);
}